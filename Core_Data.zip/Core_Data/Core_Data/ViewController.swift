//
//  ViewController.swift
//  Core_Data
//
//  Created by Parth Goswami on 10/06/18.
//  Copyright © 2018 Parth Goswami. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {


    @IBOutlet weak var tbl: UITableView!
    
    var People = [User]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let fetchrequest: NSFetchRequest<User> = User.fetchRequest()
        
        do {
            let people = try persistenceServe.contex.fetch(fetchrequest)
            
            self.People = people
            self.tbl.reloadData()
            
        } catch  {
            
        }
        
    }


    
    @IBAction func btn(_ sender: Any) {
        
        
        let alt = UIAlertController(title: "ADD", message: nil, preferredStyle: .alert)
        
        alt.addTextField { (textfield) in
            
            textfield.placeholder = "Name"
            
        }
        
        alt.addTextField { (textfield) in
            
            textfield.placeholder = "Password"
            
        }
        
        let action = UIAlertAction(title: "Add details", style: .default) { (_) in
            
            let name = alt.textFields!.first!.text!
            let pass = alt.textFields!.last!.text!
            
            let user = User(context: persistenceServe.contex)
            
            user.name = name
            user.pass = pass
            
            persistenceServe.saveContext()
            
            self.People.append(user)
            self.tbl.reloadData()
            
        }
        
        alt.addAction(action)
        
        self.present(alt, animated: true, completion: nil)
        
    }
    
    
}

extension ViewController: UITableViewDataSource,UITableViewDelegate{
   
    
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        
        return 1
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return People.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: nil)

        cell.textLabel?.text = People[indexPath.row].name
        
        cell.detailTextLabel?.text = People[indexPath.row].pass
        
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        
        
        
        
    }
    
    
}
